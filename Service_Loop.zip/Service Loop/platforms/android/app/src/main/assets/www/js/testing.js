function bigger(a, b) {
	if(a > b) {
		return "A is bigger than B";
	}	 
	else {
		return "B is bigger than A";	
	}
}

module.exports = bigger;
